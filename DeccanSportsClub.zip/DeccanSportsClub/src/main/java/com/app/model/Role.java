package com.app.model;

public enum Role {

	ADMIN, MANAGER, USER

}
