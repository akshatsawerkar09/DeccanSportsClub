package com.app.model;

public enum MemberShipType {

	YEARLY, QUATERLY, MONTHLY

}
