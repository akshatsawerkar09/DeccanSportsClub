package com.app.model;

public enum BatchName {

	MORNING, AFTERNOON, EVENING
}
