package com.app.model;

public enum SportsCategory {
	
	INDOOR, OUTDOOR

}
