package com.app.dto;

public class SportsPriceDTO {

}
