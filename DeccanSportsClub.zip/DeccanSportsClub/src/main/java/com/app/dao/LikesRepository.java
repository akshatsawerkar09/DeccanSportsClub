package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.model.Batches;
import com.app.model.Likes;
import com.app.model.Users;

@Repository
public interface LikesRepository extends JpaRepository<Likes, Integer> {

	Likes findByUserIdAndBatchId(Users users, Batches batches);

}
