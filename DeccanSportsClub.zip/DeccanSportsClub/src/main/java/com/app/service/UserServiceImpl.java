package com.app.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.BatchRepository;
import com.app.dao.EnrolledSportsRepository;
import com.app.dao.LikesRepository;
import com.app.dao.MembershipRepository;
import com.app.dao.UserRepository;
import com.app.model.Batches;
import com.app.model.EnrolledSports;
import com.app.model.Likes;
import com.app.model.MemberShipType;
import com.app.model.Membership;
import com.app.model.Users;

@Service
@Transactional
public class UserServiceImpl implements IUserService {

	@Autowired
	private UserRepository userRepo;
	@Autowired
	private EnrolledSportsRepository enrolledSportsRepo;
	@Autowired
	private BatchRepository batchRepo;
	@Autowired
	private MembershipRepository membershipRepo;
	@Autowired
	private LikesRepository LikesRepo;

	@Override
	public Users getUserById(int userId) {

		return userRepo.findById(userId).get();
	}

	@Override
	public void deleteUserById(int userId) {

		userRepo.deleteById(userId);
	}

	@Override
	public Users updateUser(Users users) {
		return userRepo.save(users);
	}

	@Override
	public Users registerUser(Users users) {

		return userRepo.save(users);
	}

	@Override
	public Users authenticateUser(String userName, String password) {

		return userRepo.findUsersByUserNameAndPassword(userName, password);
	}

	@Override
	public int loginCount(String userName) {
		Users users = userRepo.findByUserName(userName);
		return users.getLoginAttempt();
	}

	@Override
	public Users updatePassword(Users users, String newPassword) {
		Users user = userRepo.findUsersByEmailAndPassword(users.getEmail(), users.getPassword());
		user.setPassword(newPassword);
		userRepo.save(user);
		return user;
	}

	@Override
	public Users findUserByEmailAndPassword(String email, String password) {

		return userRepo.findUsersByEmailAndPassword(email, password);
	}

	@Override
	public List<EnrolledSports> findEnrolledSportsBySportsId(int sportsId) {

		return enrolledSportsRepo.findBySportsId(sportsId);
	}

	@Override
	public EnrolledSports userEnrolledSports(EnrolledSports enrolledSports) {

		return enrolledSportsRepo.save(enrolledSports);
	}

	@Override
	public EnrolledSports approveUser(int enrolledId) {
		EnrolledSports enrolledSports = enrolledSportsRepo.findByEnrolledId(enrolledId);
		enrolledSports.setEnrolledStatus(1);
		enrolledSportsRepo.save(enrolledSports);
		return enrolledSports;
	}

	@Override
	public Users checkUserName(String userName) {
		Users users = userRepo.findByUserName(userName);
		return users;
	}

	@Override
	public void incrementCount(String userName) {
		Users users = userRepo.findByUserName(userName);
		int count = users.getLoginAttempt();
		users.setLoginAttempt(count + 1);
		userRepo.save(users);
	}

	@Override
	public void setLoginCountZero(String userName) {
		Users users = userRepo.findByUserName(userName);
		users.setLoginAttempt(0);
		userRepo.save(users);

	}

	@Override
	public List<EnrolledSports> viewEnrolledBatches(int userId) {

		List<EnrolledSports> enrolledSportsList = enrolledSportsRepo.findEnrolledSportsByUserId(getUserById(userId));
		System.out.println(enrolledSportsList);
		return enrolledSportsList;

	}

	@Override
	public Membership addMembership(int userId, String membershipType, double cost) {
		if (membershipType.equals("YEARLY")) {
			Users users = getUserById(userId);
			Membership membership = new Membership(MemberShipType.YEARLY, LocalDate.now(), LocalDate.now().plusYears(1),
					cost, users);
			membershipRepo.save(membership);
			return membership;
		}
		if (membershipType.equals("QUATERLY")) {
			Users users = getUserById(userId);
			Membership membership = new Membership(MemberShipType.YEARLY, LocalDate.now(),
					LocalDate.now().plusMonths(3), cost, users);
			membershipRepo.save(membership);
			return membership;
		}
		if (membershipType.equals("MONTHLY")) {
			Users users = getUserById(userId);
			Membership membership = new Membership(MemberShipType.YEARLY, LocalDate.now(),
					LocalDate.now().plusMonths(1), cost, users);
			membershipRepo.save(membership);
			return membership;
		}

		return null;

	}

	@Override
	public Membership renewMembership(int userId, String membershipType, double cost) {
		if (membershipType.equals("YEARLY")) {
			Membership membership = membershipRepo.findByUserId(userId);
			LocalDate endDate = membership.getEndDate().plusYears(1);
			membership.setEndDate(endDate);
			membershipRepo.save(membership);
			return membership;
		}
		if (membershipType.equals("QUATERLY")) {
			Membership membership = membershipRepo.findByUserId(userId);
			LocalDate endDate = membership.getEndDate().plusMonths(3);
			membership.setEndDate(endDate);
			membershipRepo.save(membership);
			return membership;
		}
		if (membershipType.equals("MONTHLY")) {
			Membership membership = membershipRepo.findByUserId(userId);
			LocalDate endDate = membership.getEndDate().plusMonths(1);
			membership.setEndDate(endDate);
			membershipRepo.save(membership);
			return membership;
		}
		return null;
	}

	@Override
	public Likes addLikes(Likes likes) {

		return LikesRepo.save(likes);
	}

	@Override
	public void removeLikes(Likes likes) {

		LikesRepo.delete(likes);
	}

	@Override
	public Likes likeStatus(Users users, Batches batches) {

		return LikesRepo.findByUserIdAndBatchId(users, batches);
	}

}
